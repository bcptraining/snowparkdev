#  This is a backup from Nov 9 before changes to use COPY INTO with error handling.
#  It includes incomplete enhancements to error logging in the reject table.

from snowflake.snowpark import Session
from snowflake.snowpark.functions import col, lit, when, current_timestamp
from snowflake.snowpark.types import StringType
from typing import List, Optional
import json
from snowflake.snowpark.functions import struct, to_variant
import sys
from pathlib import Path
from datetime import datetime


def load_named_config(config_name: str) -> dict:
    """Load configuration by name following framework patterns. Fail if not found."""
    try:
        config_path = Path(__file__).parent.parent / \
            "config" / f"{config_name}.json"
        if config_path.exists():
            with open(config_path, 'r') as f:
                return json.load(f)
        raise FileNotFoundError(
            f"Configuration '{config_name}' not found at {config_path}")
    except FileNotFoundError:
        raise
    except (json.JSONDecodeError, IOError) as e:
        raise RuntimeError(f"Failed to load config '{config_name}': {str(e)}")


def load_named_schema(schema_name: str) -> list[dict]:
    """Load schema definition by name following framework patterns. Fail if not found."""
    try:
        schema_path = Path(__file__).parent.parent / \
            "schemas" / f"{schema_name}.json"
        if schema_path.exists():
            with open(schema_path, 'r') as f:
                return json.load(f)
        raise FileNotFoundError(
            f"Schema '{schema_name}' not found at {schema_path}")
    except FileNotFoundError:
        raise
    except (json.JSONDecodeError, IOError) as e:
        raise RuntimeError(f"Failed to load schema '{schema_name}': {str(e)}")


def copy_to_table_proc(session: Session, schema_key: str = "copy_to_snowstg_udemy"):
    """Copy data with reject handling integrated - following framework patterns"""

    # Load config from JSON file following framework config patterns
    config = load_named_config(schema_key)

    database_name = config["Database_name"]
    schema_name = config["Schema_name"]
    target_table = config["Target_table"]
    reject_table = config["Reject_table"]
    source_location = config["Source_location"]
    file_format = config["file_format"]

    # Create full table names following framework patterns
    source_location_full_name = f"{database_name}.{schema_name}.{source_location}"
    target_full_name = f"{database_name}.{schema_name}.{target_table}"
    reject_full_name = f"{database_name}.{schema_name}.{reject_table}"

    try:
        # Debug: Check what we're actually reading
        print(f"DEBUG: Source location: {source_location}")
        print(
            f"DEBUG: Config target_columns: {config.get('target_columns', [])}")
        print(f"DEBUG: Target table from config: {target_table}")
        print(f"DEBUG: Full target table name: {target_full_name}")

        # Comprehensive table validation with detailed debugging
        try:
            # First, verify the exact table we're targeting
            current_database = session.sql(
                "SELECT CURRENT_DATABASE()").collect()[0][0]
            current_schema = session.sql(
                "SELECT CURRENT_SCHEMA()").collect()[0][0]
            print(
                f"DEBUG: Current database: {current_database}, Current schema: {current_schema}")

            # Check if target table exists exactly as specified
            table_check_sql = f"SHOW TABLES LIKE '{target_table}' IN DATABASE {database_name}"
            table_results = session.sql(table_check_sql).collect()
            print(
                f"DEBUG: Tables matching '{target_table}': {[row.asDict() for row in table_results]}")

            if not table_results:
                return f"FAILED: No table found matching '{target_table}' in database {database_name}"

            # Get the exact schema of our target table
            table_desc = session.sql(
                f"DESC TABLE {target_full_name}").collect()
            table_columns = [row['name'] for row in table_desc]
            table_types = [row['type'] for row in table_desc]
            config_columns = config.get("target_columns", [])

            print(
                f"DEBUG: Target table {target_full_name} has {len(table_columns)} columns:")
            for i, (col_name, col_type) in enumerate(zip(table_columns, table_types)):
                print(f"  {i+1}. {col_name} ({col_type})")

            print(
                f"DEBUG: Config expects {len(config_columns)} columns: {config_columns}")

        except Exception as schema_err:
            return f"FAILED: Could not validate table {target_full_name}: {schema_err}"

        # Read data from stage with enhanced debugging
        try:
            df_raw = session.read.option("FIELD_DELIMITER", file_format["field_delimiter"]) \
                .option("SKIP_HEADER", file_format["skip_header"]) \
                .option("FIELD_OPTIONALLY_ENCLOSED_BY", file_format.get("field_optionally_enclosed_by", "\"")) \
                .csv(source_location)

            # Debug: Check actual data structure
            print(
                f"DEBUG: CSV DataFrame has {len(df_raw.columns)} columns: {df_raw.columns}")
            print(f"DEBUG: DataFrame schema: {df_raw.schema}")

            # Show sample data to verify column content
            try:
                sample_data = df_raw.limit(3).collect()
                print(f"DEBUG: Sample data (first 3 rows):")
                for i, row in enumerate(sample_data):
                    print(f"  Row {i+1}: {row.asDict()}")
            except Exception as sample_err:
                print(f"DEBUG: Could not collect sample data: {sample_err}")

        except Exception as read_err:
            # Fallback: try reading without enclosing character
            try:
                df_raw = session.read.option("FIELD_DELIMITER", file_format["field_delimiter"]) \
                    .option("SKIP_HEADER", file_format["skip_header"]) \
                    .option("FIELD_OPTIONALLY_ENCLOSED_BY", "") \
                    .csv(source_location)
            except Exception as fallback_err:
                # Create reject table and record error (MUST MATCH ACTUAL SCHEMA)
                create_reject_table_sql = f"""
                CREATE TABLE IF NOT EXISTS {reject_full_name} (
                    SOURCE_ROW VARIANT,
                    SOURCE_LOCATION VARCHAR(255),
                    FILE_PATH VARCHAR(1000),
                    FILE_NAME VARCHAR(255),
                    LINE_NUMBER NUMBER(38,0),
                    ERROR_MESSAGE VARCHAR(1000),
                    REJECTED_AT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP()
                )
                """
                session.sql(create_reject_table_sql).collect()
                # Pepare values for error insert
                err_text = str(fallback_err).replace("'", "''")
                source_location = source_location_full_name,
                file_path = source_location_full_name,
                file_name = source_location_full_name,
                line_number = None

                # err_text = str(fallback_err).replace("'", "''")
                # session.sql(
                #     f"""INSERT INTO {reject_full_name}
                #     (FIRST_NAME, LAST_NAME, EMAIL, ADDRESS, CITY, DOJ, ERROR_MESSAGE, FILE_NAME, LINE_NUMBER, REJECTED_AT)
                #     SELECT NULL, NULL, NULL, NULL, NULL, NULL, '{err_text}', NULL, NULL, CURRENT_TIMESTAMP()
                #     """).collect()
                # return f"FAILED: CSV parse error; wrote error to {reject_full_name}: {err_text}"

                session.sql(f"""
                    INSERT INTO {reject_full_name}
                    (SOURCE_ROW, SOURCE_LOCATION, FILE_PATH, FILE_NAME, LINE_NUMBER, ERROR_MESSAGE, REJECTED_AT)
                    SELECT NULL,
                        '{source_location}',
                        '{file_path}',
                        '{file_name}',
                        {line_number if line_number else 'NULL'},
                        '{err_text}',
                        CURRENT_TIMESTAMP()
                """).collect()
                return f"FAILED: CSV parse error; wrote error to {reject_full_name}: {err_text}"

        # Add validation - reject records with empty/null first name
        # Enhanced validation - reject empty/null first names AND invalid dates
        df_with_validation = df_raw.with_column("is_valid",
                                                when(
                                                    # Existing validation: empty/null first name
                                                    (col("$1").is_null()) | (col("$1") == "") | (col("$1") == "NULL") |
                                                    # Enhanced date validation: Snowflake-compatible patterns
                                                    (col("$6").is_null()) | (col("$6") == "") |
                                                    # Match invalid date patterns - case sensitive variations
                                                    (col("$6").rlike("^(invalid|Invalid|INVALID|null|Null|NULL).*$")) |
                                                    (col("$6").rlike("^(n/a|N/A|none|None|NONE|na|Na|NA)$")) |
                                                    (col("$6").rlike("^(0000-00-00|invalid-date|Invalid-Date)$")) |
                                                    # Match whitespace-only strings
                                                    (col("$6").rlike("^\\s*$")) |
                                                    # Catch dates that don't match standard patterns (more permissive)
                                                    ((col("$6").isNotNull()) & (col("$6") != "") &
                                                     ~col("$6").rlike("^\\d{4}-\\d{2}-\\d{2}$") &
                                                        ~col("$6").rlike("^\\d{1,2}/\\d{1,2}/\\d{4}$") &
                                                        ~col("$6").rlike("^\\d{1,2}-\\d{1,2}-\\d{4}$")),
                                                    False
                                                ).otherwise(True))

        # Split into valid and rejected records
        df_valid = df_with_validation.filter(col("is_valid") == True)
        df_rejected = df_with_validation.filter(col("is_valid") == False)

        valid_count = df_valid.count()
        reject_count = df_rejected.count()

        # Process valid records with DYNAMIC column mapping based on actual table schema
        if valid_count > 0:
            # Re-verify table schema right before insert
            table_desc = session.sql(
                f"DESC TABLE {target_full_name}").collect()
            table_columns = [row['name'] for row in table_desc]

            print(
                f"DEBUG: About to insert into table with {len(table_columns)} columns: {table_columns}")
            print(f"DEBUG: Using target table: {target_full_name}")

            # Ensure we're working with exactly 6 columns as expected
            if len(table_columns) != 6:
                return f"FAILED: Table schema changed! Expected 6 columns but found {len(table_columns)}: {table_columns}"

            # Create explicit column mapping
            df_final = df_valid.select(
                col("$1").alias("FIRST_NAME"),
                col("$2").alias("LAST_NAME"),
                col("$3").alias("EMAIL"),
                col("$4").alias("ADDRESS"),
                col("$5").alias("CITY"),
                col("$6").alias("DOJ")
            )

            print(f"DEBUG: Final DataFrame columns: {df_final.columns}")
            print(f"DEBUG: Final DataFrame count: {df_final.count()}")

            # Try to show the schema of what we're about to insert
            print(f"DEBUG: Final DataFrame schema: {df_final.schema}")

            # Double-check target table one more time before insert
            verify_table = session.sql(
                f"SELECT COUNT(*) as row_count FROM {target_full_name}").collect()
            print(
                f"DEBUG: Target table {target_full_name} currently has {verify_table[0]['ROW_COUNT']} rows")

            # Perform the actual insert with error catching and explicit column specification
            try:
                # Method 1: Use explicit INSERT INTO with SELECT to avoid column mismatch
                temp_view_name = f"temp_valid_data_{int(datetime.now().timestamp())}"
                df_final.create_or_replace_temp_view(temp_view_name)

                # Use explicit INSERT with column specification to avoid any hidden columns
                insert_sql = f"""
                INSERT INTO {target_full_name}
                (FIRST_NAME, LAST_NAME, EMAIL, ADDRESS, CITY, DOJ)
                SELECT FIRST_NAME, LAST_NAME, EMAIL, ADDRESS, CITY, DOJ
                FROM {temp_view_name}
                """

                print(f"DEBUG: Executing INSERT SQL: {insert_sql}")
                result = session.sql(insert_sql).collect()
                print(f"DEBUG: Insert result: {result}")

                # Drop the temporary view
                session.sql(f"DROP VIEW IF EXISTS {temp_view_name}").collect()

                print(
                    f"DEBUG: Successfully inserted {valid_count} records into {target_full_name}")

            except Exception as insert_err:
                # Fallback: Try the original save_as_table method with explicit schema enforcement
                try:
                    print(f"DEBUG: INSERT SQL failed, trying save_as_table fallback")
                    print(f"DEBUG: Insert error was: {str(insert_err)}")

                    # Force DataFrame to have exactly the expected schema
                    df_schema_enforced = df_valid.select(
                        col("$1").cast(StringType()).alias("FIRST_NAME"),
                        col("$2").cast(StringType()).alias("LAST_NAME"),
                        col("$3").cast(StringType()).alias("EMAIL"),
                        col("$4").cast(StringType()).alias("ADDRESS"),
                        col("$5").cast(StringType()).alias("CITY"),
                        col("$6").alias("DOJ")  # Keep as-is for DATE parsing
                    )

                    print(
                        f"DEBUG: Schema-enforced DataFrame columns: {df_schema_enforced.columns}")
                    print(
                        f"DEBUG: Schema-enforced DataFrame schema: {df_schema_enforced.schema}")

                    df_schema_enforced.write.mode(
                        "append").save_as_table(target_full_name)
                    print(f"DEBUG: Fallback method succeeded")

                except Exception as fallback_err:
                    return f"FAILED: Both INSERT and save_as_table failed. INSERT error: {str(insert_err)}. save_as_table error: {str(fallback_err)}. DataFrame had {len(df_final.columns)} columns: {df_final.columns}"

        # Handle rejected records
        if reject_count > 0:
            # No need to create table again if already exists
            df_reject_output = df_rejected.with_column(
                "ERROR_MESSAGE",
                when((col("$1").is_null()) | (col("$1") == "") | (col("$1") == "NULL"),
                     lit("Missing or empty first name"))
                .when(col("$6").rlike("^(invalid|Invalid|INVALID).*$"),
                      lit("Contains 'invalid' in DOJ field"))
                .when((col("$6").is_null()) | (col("$6") == ""),
                      lit("Missing or empty date in DOJ field"))
                .when(col("$6").rlike("^\\s*$"),
                      lit("DOJ field contains only whitespace"))
                .when(~col("$6").rlike("^\\d{4}-\\d{2}-\\d{2}$") &
                      ~col("$6").rlike("^\\d{1,2}/\\d{1,2}/\\d{4}$") &
                      ~col("$6").rlike("^\\d{1,2}-\\d{1,2}-\\d{4}$"),
                      lit("DOJ date format not recognized (expected YYYY-MM-DD, MM/DD/YYYY, or MM-DD-YYYY)"))
                .otherwise(lit("Data validation failed"))
            ).with_column(
                "FILE_NAME", lit(None)
            ).with_column(
                "LINE_NUMBER", lit(None)
            ).with_column(
                "REJECTED_AT", current_timestamp()
            ).select(
                col("$1").alias("FIRST_NAME"),
                col("$2").alias("LAST_NAME"),
                col("$3").alias("EMAIL"),
                col("$4").alias("ADDRESS"),
                col("$5").alias("CITY"),
                col("$6").alias("DOJ"),
                col("ERROR_MESSAGE"),
                col("FILE_NAME"),
                col("LINE_NUMBER"),
                col("REJECTED_AT")
            )
            df_reject_output.write.mode(
                "append").save_as_table(reject_full_name)

        return f"SUCCESS: Processed {valid_count + reject_count} records. Loaded {valid_count} valid, rejected {reject_count}. Target: {target_full_name}, Rejects: {reject_full_name if reject_count > 0 else 'None'}"

    except Exception as e:
        return f"FAILED: {str(e)} - Target: {target_full_name}"


def test_manual_proc(session: Session, test_input: str = "test"):
    """Test procedure for manual registration"""
    return f"Manual procedure test result: {test_input}"


def register_manual_procs(
    session: Optional[Session],
    stage_name: str,
    app_name: str,
    include_tags: Optional[List[str]] = None,
    dry_run: bool = False,
    verbosity: str = "summary"
) -> List[dict]:
    """Register manual procedures following framework manual procs API patterns"""

    print(
        f"📡 Manual-registering procedures for {app_name} in stage {stage_name}")

    # Define manual procedures following framework MANUAL_PROCS pattern
    manual_procedures = [
        {
            "func": copy_to_table_proc,
            "name": "copy_to_table_proc",
            "input_types": [StringType()],
            "return_type": StringType(),
            "tags": ["core"],
            "source": "manual"
        },
        {
            "func": test_manual_proc,
            "name": "test_manual_proc",
            "input_types": [StringType()],
            "return_type": StringType(),
            "tags": ["experimental"],
            "source": "manual"
        }
    ]

    normalized_tags = [tag.lower()
                       for tag in include_tags] if include_tags else None
    registered = []

    for proc in manual_procedures:
        proc["tags"] = [tag.lower() for tag in proc.get("tags", [])]

        # Tag filtering following framework validation patterns
        if normalized_tags and not any(tag in normalized_tags for tag in proc["tags"]):
            print(f"⏭️ Skipping {proc['name']} due to tag filter.")
            continue

        if dry_run:
            param_types = ", ".join(
                t.__class__.__name__ for t in proc["input_types"])
            return_type = proc["return_type"].__class__.__name__
            print(
                f"📝 Would register: {proc['name']}({param_types}) → {return_type}")
            registered.append({
                "name": proc["name"], "kind": "procedure", "tags": proc["tags"],
                "source": "manual", "status": "dry_run"
            })
            continue

        # Handle privilege issues - try to drop existing procedure first
        if session:
            try:
                drop_sql = f"DROP PROCEDURE IF EXISTS {proc['name']}(VARCHAR)"
                session.sql(drop_sql).collect()
                print(f"🗑️ Dropped existing procedure: {proc['name']}")
            except Exception as drop_error:
                print(
                    f"⚠️ Could not drop existing procedure {proc['name']}: {drop_error}")

        # Set module alias for Snowflake handler resolution
        alias_path = "app.python.procedures_man"
        sys.modules[alias_path] = sys.modules[__name__]

        # Register procedure following framework patterns
        if session:
            orig_module = getattr(proc["func"], "__module__", None)
            try:
                proc["func"].__module__ = alias_path

                session.sproc.register(
                    func=proc["func"],
                    name=proc["name"],
                    input_types=proc["input_types"],
                    return_type=proc["return_type"],
                    is_permanent=True,
                    stage_location=f"@{stage_name}",
                    imports=[f"@{stage_name}/apps/{app_name}/app.zip"],
                    packages=["snowflake-snowpark-python==1.33.0",
                              "cloudpickle==3.0.0"],
                    replace=True,
                    is_pandas=False
                )

                print(f"✅ Manually registered: {proc['name']}")
                registered.append({
                    "name": proc["name"], "kind": "procedure", "tags": proc["tags"],
                    "source": "manual", "status": "registered"
                })

            except Exception as reg_error:
                print(f"❌ Failed to register {proc['name']}: {reg_error}")
                registered.append({
                    "name": proc["name"], "kind": "procedure", "tags": proc["tags"],
                    "source": "manual", "status": "failed", "error": str(reg_error)
                })
            finally:
                if orig_module:
                    proc["func"].__module__ = orig_module

    print(
        f"\n✅ Included {len(registered)} manual procedures based on tag filter")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"🧠 Manual registration completed at {ts}")

    return registered
